<?php
		       $plugin->version = 2012021300;
               $plugin->requires = 2011032300;
		       ?>
		    