﻿<?php // $Id: tab.php,v 1.2 2008/07/01 09:44:05 moodler Exp $ 
      // tab.php - created with Moodle 1.9


$string['ajouter'] = 'הוספת דף חוצצים חדש';
$string['addtab'] = 'הוספת חוצץ חדש';
$string['changestyle'] = 'עריכת עיצוב';
$string['css'] = 'עיצוב';
$string['displaymenu'] = 'הצגת תפריט חוצצים';
$string['displaymenuagree'] = ' סמן אם ברצונך להציג את תפריט החוצצים';
$string['format'] = 'עיצוב חוצצים';
$string['menucss'] = 'עריכת תפריט עיצוב';
$string['menuname'] = 'שם התפריט';
$string['modulename'] = 'דף חוצצים';
$string['modulenameplural'] = 'דפי חוצצים';
$string['moretabs'] = 'השתמש בעוד חוצצים';
$string['name'] = 'שם';
$string['noformating'] = 'ללא עיצוב';
$string['order'] = 'המספר הסידורי של חוצץ זה';
$string['pluginname'] = 'דף חוצצים';
$string['pluginadministration'] = 'ניהול חוצצים';
$string['tab'] = 'חוצץ';
$string['tabadministration'] = 'ניהול חוצצים';
$string['tabcontent'] = 'תוכן החוצץ';
$string['tabname'] = 'שם החוצץ';
$string['taborder'] = 'מספר סידורי של החוצץ בתפריט';
$string['updatethis'] = 'ערוך דף חוצצים';

?>