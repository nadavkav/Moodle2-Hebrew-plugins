﻿<?php // $Id: tab.php,v 1.2 2008/07/01 09:44:05 moodler Exp $ 
      // tab.php - created with Moodle 1.9
$string['ajouter'] = 'Ajouter un onglet';
$string['addtab'] = 'Àjouter un onglet';
$string['changestyle'] = 'Modifier la feuille de style';
$string['css'] = 'feuille de style';
$string['displaymenu'] = 'Utiliser le menu d\'onglet disponibles';
$string['displaymenuagree'] = 'Cochez si vous désirez utiliser le menu';
$string['format'] = 'Formattage d\'onglet';
$string['menucss'] = 'Modifier la feuille de style du menu';
$string['menuname'] = 'Nom du menu';
$string['modulename'] = 'Onglet';
$string['modulenameplural'] = 'Onglets';
$string['moretabs'] = 'Utiliser plus d\'onglet';
$string['name'] = 'Nom';
$string['noformating'] = 'Aucun formatage';
$string['order'] = 'L\'ordre de cette onglet';
$string['pluginname'] = 'Onglet';
$string['tab'] = 'Onglet';
$string['tabadministration'] = 'Administration des onglets';
$string['tabcontent'] = 'Content de l\'onglet';
$string['tabname'] = 'Nom de l\'onglet';
$string['taborder'] = 'Ordre des onglet dans le menu';
$string['updatethis'] = 'Update this tab display';

?>