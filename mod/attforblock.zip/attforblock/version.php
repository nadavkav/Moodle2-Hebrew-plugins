<?PHP

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of attforblock
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2011071600;  // The current module version (Date: YYYYMMDDXX)
$module->release = '2.4.0';
$module->cron     = 0;           // Period for cron to check this module (secs)
?>
