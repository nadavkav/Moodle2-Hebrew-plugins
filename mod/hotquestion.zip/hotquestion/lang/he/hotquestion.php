﻿<?php

$string['allowanonymouspost'] = 'אשר שאלות אנונימיות';
$string['anonymous'] = 'אנונימי';
$string['authorinfo'] = 'נשאלה על ידי {$a->user} ב-{$a->time}';
$string['displayasanonymous'] = 'הצג באנונימיות';
$string['heat'] = 'רלוונטיות';
$string['hotquestionintro'] = 'נושא';
$string['hotquestionname'] = 'שם הפעילות';
$string['hotquestion:ask'] = 'שאל שאלה';
$string['hotquestion:manage'] = 'נהל שאלות';
$string['hotquestion:view'] = 'הצג שאלות';
$string['hotquestion:vote'] = 'הצבע עבור שאלה';
$string['inputquestion'] = 'שאל שאלתך כאן:';
$string['invalidquestion'] = 'לא ניתן לשאול שאלה ריקה';
$string['modulename'] = 'שאלה חמה';
$string['modulenameplural'] = 'שאלות חמות';
$string['newround'] = 'התחל סיבוב חדש';
$string['newroundconfirm'] = 'אתה בטוח ? (שאלות קודמות ודירוגן יישמר בארכיון)';
$string['noquestions'] = 'אין שאלות כרגע.';
$string['pluginadministration'] = 'ניהול תוסף';
$string['question'] = 'שאלות';
$string['questionsubmitted'] = 'שאלתך נשאלה בהצלחה.';
$string['round'] = 'סיבוב {$a}';
$string['vote'] = 'הצבע';
