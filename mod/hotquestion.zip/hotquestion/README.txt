The first moodle activity for physical classroom. The idea comes from
Purdue University's hotseat.

Inside or outside classroom, students post questions into Hot Question
activity from notebook, netbook, android, iPhone, iPod and other gears
which can access the moodle site. Students can also vote on others' 
questions, so that the hottest questions will be popped up. Teachers 
can make orally comments on selected questions in classroom.

Details: https://github.com/hit-moodle/moodle-mod_hotquestion/wiki
