<?php // $Id: game.php,v 1.2 2010/09/15 21:08:20 bdaloukas Exp $
      // translation to Hebrew (he) by Nadav Kavalerchik 

$string[ 'lettersall'] = 'אבגדהוזחטיכלמנסעפצקרשתךףץןם ';

//bookquiz/importodt.php
$string[ 'bookquiz_import_odt'] = 'יבוא מקובץ אופן אופיס (odt)';
$string[ 'bookquiz_subchapter'] = 'יצירת תת פרקים';

//bookquiz/play.php
$string[ 'bookquiz_empty'] = 'הספר ריק';

//bookquiz/questions.php
$string[ 'bookquiz_categories'] = 'סיווגים';
$string[ 'bookquiz_chapters'] = 'פרקים';
$string[ 'bookquiz_not_select_book'] = 'לא בחרתם ספר';
$string[ 'bookquiz_numquestions'] = 'שאלות';
$string[ 'bookquiz_questions'] = 'קישור סיווג שאלות לפרק בספר';

//cross/cross_class.php
$string[ 'millionaire_letters_answers'] = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

//cross/crossdb_class.php
$string[ 'and'] = 'וגם';
$string[ 'cross_correct'] = 'נכון';
$string[ 'cross_corrects'] = 'נכונים';
$string[ 'cross_error'] = 'טעות';
$string[ 'cross_errors'] = 'טעויות';
$string[ 'cross_found_many'] = 'מספר התאמות';
$string[ 'cross_found_one'] = 'התאמה בודדת';

//cross/play.php
$string[ 'cross_across'] = 'תשבץ';
$string[ 'cross_checkbutton'] = 'בדיקת תשבץ';
$string[ 'cross_down'] = 'מטה';
$string[ 'cross_endofgamebutton'] = 'End of crossword game';
$string[ 'cross_error_containsbadchars'] = 'המילה מכילה תווים לא תקינים';
$string[ 'cross_error_wordlength1'] = 'המילה הנכונה מכילה ';
$string[ 'cross_error_wordlength2'] = ' אותיות.';
$string[ 'cross_new'] = 'משחק חדש';
$string[ 'cross_nowords'] = 'לא נמצאה אף מילה';
$string[ 'cross_pleasewait'] = 'אנא המתינו בזמן שהתשבץ נטען';
$string[ 'cross_welcome'] = '<h3>ברוכים הבאים!</h3><p>לחצו על מילה להתחיל.</p>';
$string[ 'cross_win'] = 'כל הכבוד !!!';
$string[ 'letter'] = 'אות';
$string[ 'letters'] = 'אותיות';
$string[ 'print'] = 'Print';

//cryptex/play.php
$string[ 'cryptex_nowords'] = 'לא נמצאה אף מילה';
$string[ 'cryptex_win'] = 'כל הכבוד !!!!';
$string[ 'finish'] = 'המשחק הסתיים';
$string[ 'grade'] = 'Grade';
$string[ 'nextgame'] = 'משחק חדש';

//hangman/play.php
$string[ 'hangman_grade'] = 'ציון';
$string[ 'hangman_gradeinstance'] = 'הציון הכללי במשחק';
$string[ 'hangman_letters'] = 'אותיות: ';
$string[ 'hangman_loose'] = '<BIG><B>המשחק הסתיים</B></BIG>';
$string[ 'hangman_nowords'] = 'לא נמצאו מילים';
$string[ 'hangman_win'] = 'נצחתם, כל הכבוד';
$string[ 'hangman_wrongnum'] = 'טעויות: %%d מתוך %%d';
$string[ 'nextword'] = 'מילה חדשה';

//hiddenpicture/play.php
$string[ 'hiddenpicture_grade'] = 'Grade';
$string[ 'hiddenpicture_mainsubmit'] = 'Grade main answer';
$string[ 'hiddenpicture_nocols'] = 'Have to specify the number of cols horizontaly';
$string[ 'hiddenpicture_nomainquestion'] = 'There are no glossary entries on glossary {$a->name} with an attached picture';
$string[ 'hiddenpicture_norows'] = 'Have to specify the number of cols verticaly';
$string[ 'hiddenpicture_win'] = 'Congratulations';
$string[ 'must_select_glossary'] = 'יש לבחור אגרון';

//millionaire/play.php
$string[ 'millionaire_info_people'] = 'אנשים אומרים';
$string[ 'millionaire_info_telephone'] = 'אני חושב/ת שהתשובה הנכונה היא ';
$string[ 'millionaire_info_wrong_answer'] = 'תשובתכם שגוייה<br>התשובה הנכונה היא:';
$string[ 'millionaire_must_select_questioncategory'] = 'יש לבחור סיווג שאלות אחד ';
$string[ 'millionaire_must_select_quiz'] = 'יש לבחור מבחן אחד';
$string[ 'millionaire_nowords'] = 'לא נמצאה אף מילה';
$string[ 'millionaire_sourcemodule_must_quiz_question'] = 'עבור משחק המיליונר מקור השאלות צריך להיות {$a} או שאלות ולא';
$string[ 'millionaire_win'] = 'ניצחתם, כל הכבוד !!!!';
$string[ 'must_select_questioncategory'] = 'יש לבחור סיווג לשאלות';
$string[ 'must_select_quiz'] = 'You must select a quiz';

//report/default.php
$string[ 'modulename'] = 'משחק';
$string[ 'modulenameplural'] = 'משחקים';

//snakes/play.php
$string[ 'snakes_new'] = 'משחק חדש';
$string[ 'snakes_win'] = 'ניצחתם ! כל הכבוד';

//sudoku/create.php
$string[ 'sudoku_create_count'] = 'מספר לוחות סודוקו העומדים להיווצר';
$string[ 'sudoku_create_start'] = 'התחלת יצירת לוחות סודוקו';
$string[ 'sudoku_creating'] = 'מייצר <b>{$a}</b> לוחות סודוקו';

//sudoku/play.php
$string[ 'sudoku_finishattemptbutton'] = 'End of sudoku game';
$string[ 'sudoku_guessnumber'] = 'נחשו את המספר הנכון';
$string[ 'sudoku_noentriesfound'] = 'לא נמצאו מילים באגרון';
$string[ 'sudoku_submit'] = 'Grade answers';
$string[ 'sudoku_win'] = 'ניצחתם, כל הכבוד !!!';

//accessrules.php
$string[ 'confirmstartattemptlimit'] = 'This game is limited to {$a} attempt(s). You are about to start a new attempt.  Do you wish to proceed?';
$string[ 'confirmstartattempttimelimit'] = 'This game has a time limit and is limited to {$a] attempt(s). You are about to start a new attempt.  Do you wish to proceed?';
$string[ 'confirmstarttimelimit'] = 'למשחק זה יש הגבלת זמן. האם אתם מעוניינים להתחיל עכשיו?';
$string[ 'review'] = 'Review';

//attempt.php
$string[ 'useupdategame'] = 'Use the button \"Update this game\" to set the details of the game';

//attemptlib.php
$string[ 'startagain'] = 'Start again';

//export.php
$string[ 'export'] = 'Export';
$string[ 'html_hascheckbutton'] = 'Has check button:';
$string[ 'html_hasprintbutton'] = 'Has print button:';
$string[ 'html_title'] = 'Title of html:';
$string[ 'javame_createdby'] = 'Created by:';
$string[ 'javame_description'] = 'Description:';
$string[ 'javame_filename'] = 'Filename:';
$string[ 'javame_icon'] = 'Icon:';
$string[ 'javame_maxpicturewidth'] = 'Max picture width:';
$string[ 'javame_name'] = 'Name:';
$string[ 'javame_type'] = 'Type:';
$string[ 'javame_vendor'] = 'Vendor:';
$string[ 'javame_version'] = 'Version:';

//exporthtml_hangman.php

//hangman/play.php
$string[ 'hangman_correct_phrase'] = 'המשפט הנכון הוא: ';
$string[ 'hangman_correct_word'] = 'המילה הנכונה היא: ';
$string[ 'hangman_restletters_many'] = 'יש לכם <b>{$a}</b> נסיונות';
$string[ 'hangman_restletters_one'] = 'יש לכם ניסיון <b>אחד</b> בלבד';

//index.php
$string[ 'game'] = 'משחק';

//lib.php
$string[ 'attempt'] = 'ניסיון';
$string[ 'game_bookquiz'] = 'ספר עם שאלות';
$string[ 'game_cross'] = 'תשבץ';
$string[ 'game_cryptex'] = 'Cryptex';
$string[ 'game_hangman'] = 'הצילו את האיש התלוי';
$string[ 'game_hiddenpicture'] = 'Hidden Picture';
$string[ 'game_millionaire'] = 'מי רוצה להיות מיליונר';
$string[ 'game_snakes'] = 'סולמות ונחשים';
$string[ 'game_sudoku'] = 'סודוקו';
$string[ 'info'] = 'מידע';
$string[ 'noattempts'] = 'No attempts have been made on this game';
$string[ 'percent'] = 'Percent';
$string[ 'results'] = 'תוצאות';

//locallib.php

//mod_form.php
$string[ 'attemptfirst'] = 'ניסיון ראשון';
$string[ 'attemptlast'] = 'ניסיון אחרון';
$string[ 'bottomtext'] = 'המלל בתחתית';
$string[ 'cross_layout'] = 'מבנה תצורה';
$string[ 'cross_layout0'] = 'המשפט יופיע תחת התשבץ';
$string[ 'cross_layout1'] = 'המשפט יופיע מימין לתשבץ';
$string[ 'cross_maxcols'] = 'מספר עמודות מירבי בתשבץ';
$string[ 'cross_maxwords'] = 'מספר מילים מירבי בתשבץ';
$string[ 'cryptex_maxcols'] = 'מספר העמודות/שורות במשחק cryptex';
$string[ 'cryptex_maxwords'] = 'מספר המילים במשחק cryptex';
$string[ 'gradeaverage'] = 'ציון ממוצע';
$string[ 'gradehighest'] = 'הציון הגובהה ביותר';
$string[ 'grademethod'] = 'שיטת מתן ציונים';
$string[ 'hangman_allowspaces'] = 'אפשרות לרווחים במילים';
$string[ 'hangman_allowsub'] = 'אפשרות לתו - במילים';
$string[ 'hangman_imageset'] = 'בחרו תמונה למשחק האיש התלוי';
$string[ 'hangman_language'] = 'שפת המילים';
$string[ 'hangman_maxtries'] = 'מספר מילים בכל משחק';
$string[ 'hangman_showcorrectanswer'] = 'הצגת התשובה הנכונה בסוף כל משחק';
$string[ 'hangman_showfirst'] = 'הצגת האות הראשונה במשחק האיש התלוי';
$string[ 'hangman_showlast'] = 'הצגת האות האחרונה במשחק האיש התלוי';
$string[ 'hangman_showquestion'] = 'להציג את השאלות ?';
$string[ 'hiddenpicture_across'] = 'Cells horizontal';
$string[ 'hiddenpicture_down'] = 'Cells down';
$string[ 'hiddenpicture_height'] = 'קבעו גובה תמונה ל';
$string[ 'hiddenpicture_pictureglossary'] = 'The glossary for main question and picture';
$string[ 'hiddenpicture_width'] = 'קבעו רוחב תמונה ל';
$string[ 'snakes_background'] = 'רקע';
$string[ 'sourcemodule'] = 'מקור השאלות';
$string[ 'sourcemodule_book'] = 'בחרו ספר';
$string[ 'sourcemodule_glossary'] = 'בחרו אגרון';
$string[ 'sourcemodule_glossarycategory'] = 'בחרו סיווג עבור אגרון';
$string[ 'sourcemodule_include_subcategories'] = 'Include subcategories';
$string[ 'sourcemodule_question'] = 'שאלות';
$string[ 'sourcemodule_questioncategory'] = 'בחרו סיווג לשאלות';
$string[ 'sourcemodule_quiz'] = 'בחרו מבחן';
$string[ 'sudoku_maxquestions'] = 'מספר שאלות מירבי';

//preview.php
$string[ 'only_teachers'] = 'רק מורה יכול לראות דף זה';
$string[ 'preview'] = 'תצוגה מקדימה';

//review.php
$string[ 'attempts'] = 'Attempts';
$string[ 'completedon'] = 'Completed on';
$string[ 'feedback'] = 'משוב';
$string[ 'outof'] = '{$a->grade} out of a maximum of {$a->maxgrade}';
$string[ 'reviewofattempt'] = 'Review of Attempt {$a}';
$string[ 'score'] = 'Score';
$string[ 'startedon'] = 'Started on';
$string[ 'timetaken'] = 'זמן המשחק';
$string[ 'unfinished'] = 'open';

//showanswers.php
$string[ 'feedbacks'] = 'ההודעה במצב של תשובה נכונה';
$string[ 'showanswers'] = 'הצגת תשובות';

//showattempts.php
$string[ 'lastip'] = 'כתובת ה IP של התלמיד';
$string[ 'showsolution'] = 'פתרון';
$string[ 'timefinish'] = 'המשחק הסתיים';
$string[ 'timelastattempt'] = 'ניסיון אחרון';
$string[ 'timestart'] = 'התחלה';

//tabs.php
$string[ 'overview'] = 'Overview';

//view.php
$string[ 'attemptgamenow'] = 'שחקו עכשיו';
$string[ 'continueattemptgame'] = 'המשיכו ניסיון משחק קודם שלכם';
$string[ 'reattemptgame'] = 'Reattempt game';
$string[ 'timecompleted'] = 'הושלם';
$string[ 'yourfinalgradeis'] = 'הציון הסופי שלכם למשחק זה הוא {$a}.';
