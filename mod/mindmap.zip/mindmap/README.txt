Mindmap module for Moodle 2.x
------------------------
by Tõnis Tartes

This is the original Mindmap module for moodle formerly found on ekpenso.com. 
This Mindmap module allows you to create and save simple mindmaps from within moodle.

Quick install instructions:

- ) Copy this "/mindmap"-Folder and place it in your /mod directory
- ) go go to your admin area and go to "notificatiosn"
- ) That's it

Have fun!

Thanks to original mindmap module author: Andreas Geier
Link: https://github.com/functino/Moodle-Mindmap-Module

//13.06.2012 - version 2012061300
+Refactored code

//10.06.2012 - version 2012061000
+adding access.php

//17.05.2012 - version 2012032300
+Fixed some errors when upgrading from 1.9 to 2.x

//13.01.2012 - version 2012011300
+Added licences

//12.09.2011 - version 2011091200
Everythings the same as the old one, except the backup & restore functionality.
+Fixed the editable box
+Added a Description field
+Moodle 2.x Backup/Restore
+Moodle 1.9>Moodle 2.x Restore