/* FANCY BOX INITIALIZATION */

$(document).ready(function() {

    $("a.inline").fancybox({
        'transitionIn'		: 'none',
        'transitionOut'		: 'none',
        'modal'                 : true
    });


});