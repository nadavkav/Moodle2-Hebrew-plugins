<?php

require_once dirname(__FILE__)."/../../config.php";
require_once dirname(__FILE__).'/lib/version_check.php';
require_once dirname(__FILE__).'/lib/lib.php';
