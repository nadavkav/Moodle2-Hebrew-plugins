<?php
$string['blocktitle'] = 'Course Menu';
$string['pluginname'] = 'Course Menu';
$string['namesections'] = 'Section';
$string['nametopics'] = 'Topic';
$string['nameweeks'] = 'Week';
$string['showall']='Show all';
$string['namesite']='Site';