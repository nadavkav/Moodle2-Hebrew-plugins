<?php
/* DE translation added by actxc.de 2011*/
/* Umlaute vorsichtshalber als HTML-Code einfügen */
/* use HTML-code for Umlaut */
$string['blocktitle'] = 'Kurs Men&uuml;';
$string['pluginname'] = 'Kurs Men&uuml;';
$string['namesections'] = 'Abschnitt';
$string['nametopics'] = 'Inhalt';
$string['nameweeks'] = 'Woche';
$string['showall']='Alles Zeigen';
$string['namesite']='Seite';
$string['view']='Beschreibung: ';