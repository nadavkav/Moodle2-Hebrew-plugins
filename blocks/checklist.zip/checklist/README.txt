This is a block which works with the checklist module and displays progress bars for a single checklist.

It will not work without the checklist module - which can be downloaded here: http://moodle.org/plugins/view.php?plugin=mod_checklist

==Changes==

* 2012-01-27 - French translation from Luiggi Sansonetti
* 2012-01-02 - Minor tweaks to improve Moodle 2.2+ compatibility (optional_param_array / context_module::instance )
