<?php

$string['checklist'] = 'Kontrolný zoznam';
$string['choosechecklist'] = 'Vyberte zoznam';
$string['choosegroup'] = 'Vyberte skupinu';
$string['nochecklist'] = 'Prosím upravte tento blok na zobrazenie kontrolného zoznamu';
$string['nochecklistplugin'] = 'Pre prácu s týmto blokom je potrebné nainštalovať najnovšiu verziu pluginu';
$string['nousers'] = 'Žiadni užívatelia';

?>
