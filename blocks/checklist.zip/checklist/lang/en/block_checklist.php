<?php

$string['checklist'] = 'Checklist';
$string['choosechecklist'] = 'Choose checklist';
$string['choosegroup'] = 'Choose group';
$string['nochecklist'] = 'Please edit this block to select a checklist to display';
$string['nochecklistplugin'] = 'You need to install the latest version of the checklist plugin for this block to work';
$string['nousers'] = 'No users';
$string['pluginname'] = 'Checklist';
