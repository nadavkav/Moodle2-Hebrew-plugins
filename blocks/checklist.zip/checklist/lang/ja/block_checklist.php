<?PHP // $Id$ 
      // block_checklist.php - created with Moodle 1.9.10+ (Build: 20110112) (2007101591)


$string['checklist'] = 'チェックリスト';
$string['choosechecklist'] = 'チェックリストを選択する';
$string['choosegroup'] = 'グループを選択する';
$string['nochecklist'] = '表示するチェックリストを選択するには、このブロックを編集してください。';
$string['nochecklistplugin'] = 'このブロックを動作させるため、あなたは最新バージョンのチェックリストプラグインをインストールする必要があります。';
$string['nousers'] = 'ユーザなし';
$string['pluginname'] = 'チェックリスト';

?>
