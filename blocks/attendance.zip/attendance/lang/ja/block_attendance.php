<?PHP // $Id: block_attendance.php,v 1.1.10.3 2009/04/07 17:24:08 dlnsk Exp $ 
      // block_attendance.php - created with Moodle 2.0 dev (Build: 20090403) (2009040100)


$string['blockname'] = '出欠';
$string['needactivity'] = 'このブロックは出欠活動のみと動作します。このコースに出欠活動を追加してください。';

?>
