<?PHP // $Id: block_attendance.php,v 1.1 2007/07/06 18:49:06 dlnsk Exp $ 
      // block_attendance.php - created with Moodle 1.5.3+ (2005060230)


$string['strftimedm'] = '%%m.%%d';
$string['strftimedmy'] = '%%m.%%d.%%Y';
$string['strftimedmyw'] = '%%m.%%d.%%y&nbsp;(%%a)';
$string['strftimeshortdate'] = '%%m.%%d.%%Y';

?>