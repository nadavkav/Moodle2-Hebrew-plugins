<?PHP // $Id: block_attendance.php,v 1.1.10.1 2009/02/23 19:18:56 dlnsk Exp $ 
      // block_attendance.php - created with Moodle 1.5.3+ (2005060230)


$string['blockname'] = 'Presenze';

?>
