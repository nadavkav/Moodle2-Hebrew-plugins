<?PHP // $Id: block_attendance.php,v 1.1.6.1 2009/02/23 19:18:56 dlnsk Exp $ 
      // block_attendance.php - created with Moodle 1.7.1+ (2006101010)


$string['blockname'] = 'Asistentzia';

?>
