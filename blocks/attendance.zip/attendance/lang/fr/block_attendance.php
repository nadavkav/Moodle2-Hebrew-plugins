﻿<?PHP // $Id: block_attendance.php,v 1.1.2.3 2009/02/23 19:18:56 dlnsk Exp $ 
      // block_attendance.php - created with Moodle 1.5.3+ (2005060230)


$string['blockname'] = 'Présence';
$string['needactivity'] = 'Ce bloc fonctionne uniquement avec une activité Présence. Veuillez ajouter cette activité à ce cours.';

?>