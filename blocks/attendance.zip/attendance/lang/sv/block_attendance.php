<?PHP // $Id: block_attendance.php,v 1.1.10.1 2009/02/23 19:18:57 dlnsk Exp $ 
      // block_attendance.php - created with Moodle 1.6 development (2005101200)


$string['blockname'] = 'N�rvaro';

?>
