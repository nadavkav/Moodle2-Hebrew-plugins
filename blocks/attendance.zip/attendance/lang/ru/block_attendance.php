<?PHP // $Id: block_attendance.php,v 1.4.2.1 2009/02/23 19:18:56 dlnsk Exp $ 
      // block_attendance.php - created with Moodle 1.8.2+ (2007021520)


$string['blockname'] = 'Посещаемость';
$string['needactivity'] = 'Данный блок работает только вместе с элементом курса Посещаемость. Пожалуйста добавьте этот элемент курса.';
$string['pluginname'] = 'Посещаемость';

?>