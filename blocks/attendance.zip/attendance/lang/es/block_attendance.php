<?PHP // $Id: block_attendance.php,v 1.1.4.3 2009/02/23 19:18:56 dlnsk Exp $ 
      // block_attendance.php - created with Moodle 1.5.3+ (2005060230)


$string['blockname'] = 'Asistencia';
$string['needactivity'] = 'Este Bloque solo puede trabajar con la actividad Asistencia. Por favor, añada la actividad asistencia a este curso/asignatura';

?>
