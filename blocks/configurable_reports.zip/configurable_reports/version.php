<?php
    $plugin->version = 2011040102;
    // Moodle version required
    $plugin->requires = 2010112400;
    $plugin->maturity = MATURITY_STABLE;
    $plugin->release = 2.0;
?>