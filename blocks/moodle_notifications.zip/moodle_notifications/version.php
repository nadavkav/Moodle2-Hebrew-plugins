<?php
$plugin->component  = 'block_moodle_notifications';
$plugin->version  = 2011111701;
$plugin->release  = 4;
$plugin->requires  =2011033003;
$plugin->maturity  = MATURITY_STABLE;
$plugin->cron  = 1;
?>
