<?php
  $plugin->version  = 20111031; // Plugin version (update when tables change)
  $plugin->requires = 2010112400; // Required Moodle version
  $plugin->release  = MATURITY_BETA;
  $plugin->maturity = "2.1beta2 (20111031)"; // User-friendly version number
?>