<?php

$string['namegrid']='Grid view'; // Name of a section within your format
$string['formatgrid']='Grid view'; // Name to display for format

$string['sectionname'] = 'Topic';
$string['pluginname'] = 'Grid view';

$string['hide_summary'] = 'move section into grid';
$string['display_summary'] = 'move out of grid';
$string['hide_summary_alt'] = 'Move this section into the grid';
$string['display_summary_alt'] = 'Move this section out of the grid';

$string['editimage'] = 'Set or change image';
$string['title'] = 'Topic title';
$string['image'] = 'Topic icon';
$string['titlealreadyexist'] = '$a title is already exists. Please change the title.';
$string['updatesection'] = 'Overwrote section';
$string['topicoutline'] = 'Topic';

$string['generalinformation'] ='General Information';



//$string['section0name'] = 'General';

?>