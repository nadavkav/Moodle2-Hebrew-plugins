﻿<?php

$string['namegrid']='תצוגה טבלאית'; // Name of a section within your format
$string['formatgrid']='תצוגה טבלאית'; // Name to display for format

$string['sectionname'] = 'נושא';
$string['pluginname'] = 'תצוגה טבלאית';

$string['hide_summary'] = 'העבר נושא לתוך הטבלה';
$string['display_summary'] = 'הוצא נושא מהטבלה';
$string['hide_summary_alt'] = 'מעביר את נושא זה לתוך הטבלה';
$string['display_summary_alt'] = 'מעביר את נושא זה אל מחוץ לטבלה';

$string['editimage'] = 'החלף תמונה';
$string['title'] = 'כותרת נושא';
$string['image'] = 'אייקון נושא';
$string['titlealreadyexist'] = '$a הכותרת כבר קיימת. יש להחליפה.';
$string['updatesection'] = 'Overwrote section';
$string['topicoutline'] = 'נושא';

$string['generalinformation'] = 'מידע כללי';


//$string['section0name'] = 'General';

?>