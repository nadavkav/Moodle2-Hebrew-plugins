<?php
//
// Optional course format configuration file
//
// This file contains any specific configuration settings for the
// format.
//
// The default blocks layout for this course format:
    $format['defaultblocks'] = ':search_forums,news_items,calendar_upcoming,recent_activity';
//
