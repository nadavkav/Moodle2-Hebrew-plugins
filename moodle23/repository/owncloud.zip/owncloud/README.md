moodle-repository_owncloud
==========================

Moodle 2+ OwnCloud repository that support multi users connecting into OwnCloud from Moodle and using it as a file repository (similar to Dropbox) based on Moodle's core repository implementation of WEBDAV.