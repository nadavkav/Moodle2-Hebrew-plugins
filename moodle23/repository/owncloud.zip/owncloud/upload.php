<?php

echo "<button>Upload</button>";