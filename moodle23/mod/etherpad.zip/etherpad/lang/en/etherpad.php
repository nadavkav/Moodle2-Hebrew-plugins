<?php

$string['modulename'] = 'Etherpad';
$string['modulenameplural'] = 'Etherpad';
$string['pluginadministration'] = 'Etherpad';
$string['pluginname'] = 'Etherpad';
$string['etherpadname'] = 'Name';
$string['etherpadquestion'] = 'Introduction';


