<?php

defined('MOODLE_INTERNAL') || die();

$logs = array(
    array('module'=>'etherpad', 'action'=>'view', 'mtable'=>'etherpad', 'field'=>'name'),
    array('module'=>'etherpad', 'action'=>'add entry', 'mtable'=>'etherpad', 'field'=>'name'),
    array('module'=>'etherpad', 'action'=>'update entry', 'mtable'=>'etherpad', 'field'=>'name'),
    array('module'=>'etherpad', 'action'=>'view responses', 'mtable'=>'etherpad', 'field'=>'name')
);