<?php


function xmldb_forum_upgrade($oldversion) {
    global $CFG, $DB, $OUTPUT;

    return true;
}


