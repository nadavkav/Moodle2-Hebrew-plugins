<?PHP // $Id: version.php,v 1.0 2012/03/28 12:30:00 Serafim Panov Exp $

$module->version   = 2012032800;  // The current module version (Date: YYYYMMDDXX)
$module->requires  = 2011112900;  
$module->component = 'mod_etherpad';
$module->cron      = 0;           // Period for cron to check this module (secs)
