At time of writing only the following lang folders have been updated since
Moodle 2 conversion:

en
pt_br

Other folders are the versions from Moodle 1.9, so may partially work but
the help will be missing.