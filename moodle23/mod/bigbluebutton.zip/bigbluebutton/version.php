<?php
///////////////////////////////////////////////////////////////////////////
//                                                                       //
// NOTICE OF COPYRIGHT                                                   //
//                                                                       //
//                                                                       //
// Copyright (C) 2010 Dual Code Inc. (www.dualcode.com)                  //
//                                                                       //
// This program is free software; you can redistribute it and/or modify  //
// it under the terms of the GNU General Public License version 2 as     //
// published by the Free Software Foundation.                            //
//                                                                       //
// This program is distributed in the hope that it will be useful,       //
// but WITHOUT ANY WARRANTY; without even the implied warranty of        //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         //
// GNU General Public License for more details:                          //
//                                                                       //
// http://www.gnu.org/licenses/old-licenses/gpl-2.0.html                 //
//                                                                       //
///////////////////////////////////////////////////////////////////////////

$module->version  = 2011020401;   // The (date) version of this module
$module->requires = 2011020200;   // Requires this Moodle version
?>
