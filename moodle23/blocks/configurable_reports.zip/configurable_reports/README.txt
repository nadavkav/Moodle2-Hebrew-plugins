Configurable Reports Block

Installation, Documentation, Tutorials....
See http://docs.moodle.org/en/blocks/configurable_reports/
Also http://moodle.org/mod/data/view.php?d=13&rid=4283

Author: Juan Leyva 
<http://moodle.org/user/profile.php?id=49568>
<http://twitter.com/jleyvadelgado>
<http://sites.google.com/site/mooconsole/>
<http://moodle-es.blogspot.com>
<http://openlearningtech.blogspot.com>

Thanks to:
Ivan Breziansky for translating the block to slovak language
Iñaki Arenaza for translating the block documentation to spanish
Luis de Vasconcelos for testing the block
Adam Olley and Netspot Moodle Partner for improving some parts of the Moodle2 version

Some parts of this plugin uses code of:

Admin Report: Custom SQL queries
http://moodle.org/mod/data/view.php?d=13&rid=2884
By Tim Hunt
