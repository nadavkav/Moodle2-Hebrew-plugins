## v1.1.2

- Fixed problematic anonymous function between PHP versions [#7][7], [#8][8] ([eSrem][eSrem] and [Icheb][Icheb])
- Abiding by Moodle config directory permission [#9][9] ([abias][abias])

[7]: https://github.com/lsuits/quickmail/issues/7
[8]: https://github.com/lsuits/quickmail/issues/8
[9]: https://github.com/lsuits/quickmail/issues/9

[eSrem]: https://github.com/eSrem
[Icheb]: https://github.com/Icheb
[abias]: https://github.com/abias

## v1.1.0 and v1.1.1

- Added LSU attributions ([adamzap][adamzap])
- Fleshed out README ([adamzap][adamzap])

[adamzap]: https://github.com/adamzap

## v1.0.1

- Styles and decoration ([rrusso][rrusso])

[rrusso]: https://github.com/rrusso

## v1.0.0

- Initial release
