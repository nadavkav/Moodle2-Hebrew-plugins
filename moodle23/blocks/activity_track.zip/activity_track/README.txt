Release notes

Moodle 2.1 (Build: 2011070100)

This block will help the students to view all the courses they are enrolled to along with the total number of activities in that course and how many of them are finished with overall percentage. Student can navigate to a specific course by just clicking on the course name.

Moodle 2.1 (Build: 2012020118)

Link added to all the courses for easy navigation from the block.
