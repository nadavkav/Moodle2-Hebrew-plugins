<?php
/**
 *  SharingCart_*Exception
 */

class SharingCart_Exception extends Exception {}
class SharingCart_CourseException extends SharingCart_Exception {}
class SharingCart_SectionException extends SharingCart_Exception {}
class SharingCart_ModuleException extends SharingCart_Exception {}
class SharingCart_XmlException extends SharingCart_Exception {}

?>