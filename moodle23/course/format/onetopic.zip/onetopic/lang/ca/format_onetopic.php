<?php
$string['pluginname'] = 'Temes en pestanyes'; // Name to display for format
$string['sectionname'] = 'Tema'; // Name of a section within your format
