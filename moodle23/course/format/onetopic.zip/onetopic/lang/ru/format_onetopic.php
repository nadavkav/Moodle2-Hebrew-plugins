﻿<?php
$string['sectionname'] = 'Раздел';
$string['pluginname'] = 'По одному разделу';
?>