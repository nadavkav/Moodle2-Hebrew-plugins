COURSE FORMATS Onetopic
============================

Package tested in: moodle 2.2+

QUICK INSTALL
==============
Download zip package, extract the onetopic folder and upload this folder into course/format/.

ABOUT
=============
Developed by: David Herney Bernal Garc�a - davidherney at gmail dot com
Information in: http://aprendeenlinea.udea.edu.co/lms/investigacion/course/view.php?id=50&topic=2

IN VERSION
=============

2012021301:
Compatibility with moodle 2.2

2011030101:
Change in style properties and guest access.