<?php
$string['display_summary'] = 'move out of grid';
$string['display_summary_alt'] = 'Move this section out of the grid';
$string['editimage'] = 'Set or change image';
$string['formatgrid']='Grid view'; // Name to display for format
$string['hide_summary'] = 'move section into grid';
$string['hide_summary_alt'] = 'Move this section into the grid';
$string['image'] = 'Topic icon';
$string['namegrid'] = 'Grid view'; // Name of a section within your format
$string['pluginname'] = 'Grid view';
$string['sectionname'] = 'Topic';
$string['section0name'] = 'General';
$string['title'] = 'Topic title';
$string['titlealreadyexist'] = '$a title is already exists. Please change the title.';
$string['topicoutline'] = 'Topic';
$string['updatesection'] = 'Overwrote section';
?>