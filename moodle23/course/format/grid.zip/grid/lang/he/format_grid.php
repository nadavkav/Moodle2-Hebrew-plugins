<?php
$string['display_summary'] = 'הוספת יחידת הוראה זו לטבלת התמונות';
$string['display_summary_alt'] = 'הסרת יחידת הוראה זו מטבלת התמונות';
$string['editimage'] = 'עדכון תמונה';
$string['formatgrid']='יחידות הוראה בטבלת תמונות'; // Name to display for format
$string['hide_summary'] = 'הוספת יחידת הוראה זו לטבלת התמונות';
$string['hide_summary_alt'] = 'הוספת יחידת הוראה זו לטבלת התמונות';
$string['image'] = 'סמל יחידת ההוראה';
$string['namegrid'] = 'יחידות הוראה בטבלת תמונות'; // Name of a section within your format
$string['pluginname'] = 'יחידות הוראה בטבלת תמונות';
$string['sectionname'] = 'יחידת הוראה';
$string['section0name'] = 'מבוא';
$string['title'] = 'נושא יחידת ההוראה';
$string['titlealreadyexist'] = 'הנושא $a עבור יחידת ההוראה כבר קיים. אנא בחרו נושא חדש.';
$string['topicoutline'] = 'יחידות הוראה';
$string['updatesection'] = 'עדכון יחידת הוראה';
?>