﻿<?php

$string['namegrid']='Сетка'; // Name of a section within your format
$string['formatgrid']='Сетка'; // Name to display for format

$string['sectionname'] = 'Раздел';
$string['pluginname'] = 'Сетка';

$string['hide_summary'] = 'Переместить раздел внутрь сетки';
$string['display_summary'] = 'Вынести из области сетки';
$string['hide_summary_alt'] = 'Переместить раздел внутрь сетки';
$string['display_summary_alt'] = 'Вынести из области сетки';

$string['general_information'] = 'Общая информация';
$string['hidden_section'] = 'Эта секция скрыта';

$string['editimage'] = 'Установить или изменить изображение';
$string['editimage_title'] = 'изменить изображение';
$string['title'] = 'Название раздела';
$string['image'] = 'Значок раздела';
$string['titlealreadyexist'] = 'Заголовок $a уже существует. Пожалуйста, измените его название.';
$string['updatesection'] = 'Заменить раздел';
$string['topicoutline'] = 'Разделов';

$string['section0name'] = 'Общее';