<?php
  $plugin->version  = 2012012501; // Plugin version (update when tables change)
  $plugin->requires = 2010112400; // Required Moodle version
  $plugin->release  = MATURITY_RC;
  $plugin->maturity = "2.1RC (20110118)"; // User-friendly version number
?>
