<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'theme_avalon', language 'en', branch 'MOODLE_23_STABLE'
 *
 * @package   theme_avalon
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'ערכת מכללה';
$string['region-side-post'] = 'ימין';
$string['region-side-pre'] = 'שמאל';
$string['importantnotice'] = 'הודעה חשובה';

$string['teacher'] = 'מורה';
$string['teachers'] = 'מורים';

$string['backtocourse'] = 'בחזרה לקורס';

$string['choosereadme'] = '<div class="clearfix">
    <div style="direction:ltr;text-align:left;" class="theme_screenshot"><h2>Avalon</h2><img src="avalon/pix/screenshot.png"/>

        <h3 style="direction:ltr;text-align:left;" >Theme Documentation:</h3>
        <p><a href="avalon/readme.html">Avalon\'s Readme</a></p>

        <h3 style="direction:ltr;text-align:left;" >Theme Discussion Forum:</h3>
        <p><a href="http://moodle.org/mod/forum/view.php?id=46">Moodle.org Themes main forum</a></p>
        <p><a href="https://moodle.org/mod/forum/discuss.php?d=217418">Avalon specific discussion</a></p>

        <h3 style="direction:ltr;text-align:left;" >Report a bug:</h3>
        <p><a href="http://tracker.moodle.org">http://tracker.moodle.org</a></p></div>

        <h3 style="direction:ltr;text-align:left;" >Theme Credits</h3>
        <p><a href="avalon/readme.html#credits">Macam developers team, Mofet Institute, Israel.</a></p>

    <div style="direction:ltr;text-align:left;" class="theme_description"><h2>About</h2>

        <p>Avalon is a semi fluid-width, three-column Moodle 2.3 theme with a touch of subtle rounded corners,
            multi colored presets with changing logos and more... that can be tweaked using the theme\'s setting page!

        <h2>Overview</h2>

        <p>This theme is built upon the Base theme inside the Moodle core. If you want to modify this theme, we
            recommend that you first duplicate it, then rename it before making your changes. This will prevent your
            customized theme from being overwritten by future Moodle upgrades, and you\'ll still have the original files
            if you make a mess. More information on modifying themes can be found in the <a
                    href="http://docs.moodle.org/en/Theme">MoodleDocs</a>.</p>

        <h2>Tweaking</h2>
        <p>
            The theme can be tweaked by changing the following settings:
            <ul>
                <li>
                    Change header logo background image, header logo image, footer logo image.
                    (Both for English UI and for other local language [ie. Hebrew] UI)
                </li>
                <li>
                    Change text color and background color of various UI elements (see list of available elements on theme\'s setting page.
                </li>
                <li>
    Set Icons with links to various services on the page\'s top heading bar.
                </li>
                <li>
                    Institute\'s Notice, About and Footer special (markdown) menu.
                </li>
                <li>
    Big buttons and UI elements (touch screen ready) and highlighted default submit buttons on each settings page.
                </li>
                <li>
    Emphasized (background color) current context in Navigation menu.
                </li>
                <li>
    Back to Course button (above the Navigation blocks and under the breadcrumbs navigation bar).
                </li>
                <li>
    Special RTL support (Including Right aligned Main Menu).
                </li>

        </ul>
        </p>

        <h2>Credits</h2>

        <p>This theme was originally designed for Moodle 2.3 by Mofet Institute\'s Macam developer team:
            Emil Shenkerman (Graphic UI Designer), Desmond A. Beazley (HTML & CSS Developer),
            Nitzan Bar (PHP Developer), Nadav Kavalerchik (PHP Developer).<br/><br/>
            Maintained and supported by Macam team at <a href="mailto:support@macam.ac.il">support@macam.ac.il</a><br/>
            Updated source code can be downloaded from: <a href="https://github.com/mofet">github.com/mofet</a><br/>
        </p>

        <h2>License</h2>

        <p>This, and all other themes included in the Moodle, are licensed under the <a
                href="http://www.gnu.org/licenses/gpl.html">GNU General Public License</a>.</div>
</div>';
$string['helpreadme']='עזרה, תעוד ורשיון שימוש';