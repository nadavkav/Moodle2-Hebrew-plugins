<?php

/**
 * Makes our changes to the CSS
 *
 * @param string $css
 * @param theme_config $theme
 * @return string 
 */
function avalon_process_css($css, $theme) {

    ////////// Blocks background colors

    // Set the communication blocks background color
    if (!empty($theme->settings->blockbgcolor_communication)) {
        $bgcolor = $theme->settings->blockbgcolor_communication;
    } else {
        $bgcolor = null;
    }
    $css = avalon_set_blockbgcolor_communication($css, $bgcolor);

    // Set the navigation blocks background color
    if (!empty($theme->settings->blockbgcolor_navigation)) {
        $bgcolor = $theme->settings->blockbgcolor_navigation;
    } else {
        $bgcolor = null;
    }
    $css = avalon_set_blockbgcolor_navigation($css, $bgcolor);

    // Set the information blocks background color
    if (!empty($theme->settings->blockbgcolor_information)) {
        $bgcolor = $theme->settings->blockbgcolor_information;
    } else {
        $bgcolor = null;
    }
    $css = avalon_set_blockbgcolor_information($css, $bgcolor);

    // Set the personal blocks background color
    if (!empty($theme->settings->blockbgcolor_personal)) {
        $bgcolor = $theme->settings->blockbgcolor_personal;
    } else {
        $bgcolor = null;
    }
    $css = avalon_set_blockbgcolor_personal($css, $bgcolor);


    ////////// Color presets

    // colors
    if (!empty($theme->settings->subtheme)){
        $subtheme = $theme->settings->subtheme;
    }
    else {
        $subtheme = 'sky';
    }

    $default_colors = $theme->settings->subthemedefaults[$subtheme]['colors'];
    foreach($default_colors  as $color_number => $default_setting)  {

        $colorsetting = 'color'.$color_number;

        if (!empty($theme->settings->$colorsetting)) {
            $color = $theme->settings->$colorsetting;
        } else {
            $color = null;
        }

        $css = avalon_set_color($css, $color_number,  $color , $default_setting );
    }


    ////////// Images (LOGO)

    // Set the logo image (ltr)
    if (!empty($theme->settings->logocollege)) {
        $logo = $theme->settings->logocollege;
    } else {
        $logo = null;
    }
    $css = avalon_set_logo($css, $logo);

    // Set the logo image (rtl)
    if (!empty($theme->settings->logocollegertl)) {
        $logo = $theme->settings->logocollegertl;
    } else {
        $logo = null;
    }
    $css = avalon_set_logortl($css, $logo);

    // Set the logo college footer image (ltr)
    if (!empty($theme->settings->logocollegefooter)) {
        $logocollegefooter = $theme->settings->logocollegefooter;
    } else {
        $logocollegefooter = null;
    }
    $css = avalon_set_logocollegefooter($css, $logocollegefooter);

    // Set the logo college footer image (rtl)
    if (!empty($theme->settings->logocollegefooterrtl)) {
        $logocollegefooter = $theme->settings->logocollegefooterrtl;
    } else {
        $logocollegefooter = null;
    }
    $css = avalon_set_logocollegefooterrtl($css, $logocollegefooter);

    // Set the background banner image (ltr)
    if (!empty($theme->settings->topbanner)) {
        $banner = $theme->settings->topbanner;
    } else {
        $banner = null;
    }
    $css = avalon_set_topbanner($css, $banner);

    // Set the background banner image (rtl)
    if (!empty($theme->settings->topbannerrtl)) {
        $banner = $theme->settings->topbannerrtl;
    } else {
        $banner = null;
    }
    $css = avalon_set_topbannerrtl($css, $banner);

    //Process subtheme pix locations
   $css = avalon_pix_process($css, $subtheme);

    // Return the CSS
    return $css;
}



/**
 * Sets the link color variable in CSS
 *
 */
function avalon_set_blockbgcolor_communication($css, $bgcolor) {
    $tag = '[[setting:blockbgcolor_communication]]';
    $replacement = $bgcolor;
    if (is_null($replacement)) {
        $replacement = '#32529a';
    }
    $css = str_replace($tag, $replacement, $css);
    return $css;
}

function avalon_set_blockbgcolor_navigation($css, $bgcolor) {
    $tag = '[[setting:blockbgcolor_navigation]]';
    $replacement = $bgcolor;
    if (is_null($replacement)) {
        $replacement = '#32529a';
    }
    $css = str_replace($tag, $replacement, $css);
    return $css;
}

function avalon_set_blockbgcolor_information($css, $bgcolor) {
    $tag = '[[setting:blockbgcolor_information]]';
    $replacement = $bgcolor;
    if (is_null($replacement)) {
        $replacement = '#32529a';
    }
    $css = str_replace($tag, $replacement, $css);
    return $css;
}

function avalon_set_blockbgcolor_personal($css, $bgcolor) {
    $tag = '[[setting:blockbgcolor_personal]]';
    $replacement = $bgcolor;
    if (is_null($replacement)) {
        $replacement = '#32529a';
    }
    $css = str_replace($tag, $replacement, $css);
    return $css;
}


////////// Color presets


function avalon_set_color($css, $color_number, $color_setting, $default_color) {

    $tag = '[[setting:color'.$color_number.']]';
    $replacement = $color_setting;
    if (is_null($replacement)) {
        $replacement = $default_color;;
    }
    $css = str_replace($tag, $replacement, $css);
    return $css;
}


////////// Images (LOGO)

function avalon_set_logo($css, $logo) {
	global $OUTPUT;
	$tag = '[[setting:logocollege]]';
	$replacement = "#page-header .collegelogo { background:url($logo) no-repeat; } ";
	if (is_null($logo)) {
 		$replacement = ' ';//$OUTPUT->pix_url('logo_college_default', 'theme');
 	}
	$css = str_replace($tag, $replacement, $css);
	return $css;
}

function avalon_set_logortl($css, $logo) {
    global $OUTPUT;
    $tag = '[[setting:logocollegertl]]';
    $replacement = ".dir-rtl #page-header .collegelogo { background:url($logo) no-repeat; } ";
    if (is_null($logo)) {
        $replacement = ' ';//$OUTPUT->pix_url('logo_college_default_rtl', 'theme');
    }
    $css = str_replace($tag, $replacement, $css);
    return $css;
}

function avalon_set_logocollegefooter($css, $logocollegefooter) {
    global $OUTPUT;
    $tag = '[[setting:logocollegefooter]]';
    $replacement = "#page-footer .bottomfar a.college { background:url($logocollegefooter) no-repeat; } ";
    if (is_null($logocollegefooter)) {
        $replacement = ' ';//$OUTPUT->pix_url('logo_college_footer_default', 'theme');
    }
    $css = str_replace($tag, $replacement, $css);
    return $css;
}

function avalon_set_logocollegefooterrtl($css, $logocollegefooter) {
    global $OUTPUT;
    $tag = '[[setting:logocollegefooterrtl]]';
    $replacement = ".dir-rtl #page-footer .bottomfar a.college { background:url($logocollegefooter) no-repeat; } ";
    if (is_null($logocollegefooter)) {
        $replacement = ' ';//$OUTPUT->pix_url('logo_college_footer_default_rtl', 'theme');
    }
    $css = str_replace($tag, $replacement, $css);
    return $css;
}

function avalon_set_topbanner($css, $banner) {
    global $OUTPUT;
    $tag = '[[setting:topbanner]]';
    $replacement = "#page-header { background:url($banner) no-repeat 0 0; } ";
    if (is_null($banner)) {
        $replacement = ' ';//$OUTPUT->pix_url('top_banner_default', 'theme');
    }
    $css = str_replace($tag, $replacement, $css);
    return $css;
}

function avalon_set_topbannerrtl($css, $banner) {
    global $OUTPUT;
    $tag = '[[setting:topbannerrtl]]';
    $replacement = ".dir-rtl #page-header { background:url($banner) no-repeat 100% 0; } ";
    if (is_null($banner)) {
        $replacement = ' ';//$OUTPUT->pix_url('top_banner_default_rtl', 'theme');
    }
    $css = str_replace($tag, $replacement, $css);
    return $css;
}



function avalon_pix_process($css, $subtheme) {
    global $OUTPUT;
    // now resolve all image locations
    if (preg_match_all('/\[\[avalon_pix:([a-z_]+\|)?([^\]]+)\]\]/', $css, $matches, PREG_SET_ORDER)) {
        $replaced = array();
        foreach ($matches as $match) {
            if (isset($replaced[$match[0]])) {
                continue;
            }
            $replaced[$match[0]] = true;
            $imagename = $match[2];
            $component = rtrim($match[1], '|');
            $imageurl = $OUTPUT->avalon_pix_url($imagename, $component, $subtheme)->out(false);
            // we do not need full url because the image.php is always in the same dir
            $imageurl = preg_replace('|^http.?://[^/]+|', '', $imageurl);
            $css = str_replace($match[0], $imageurl, $css);
        }
    }

    return $css;
}

/**
 * This function creates javascript code to reset to default subtheme colors
 * Used in admin settings (settings.php)
 */
function buildResetDefaultColorsJS($subthemedefaults){

    //Prepare color variable (Holds all subtheme's default colors
    $colors_var = 'var colors = { };';

    foreach ($subthemedefaults as $subtheme => $defaults){
        $colors_var  .=  'colors.'.$subtheme.'= { };';
        foreach ($defaults['colors'] as $color_number => $color_value){
            $colors_var .= 'colors.'.$subtheme.'['.$color_number.']='.'\''.$color_value.'\';';
        }
    }

    $resetDefaultColorsText = get_string('resetdefaultcolors', 'theme_avalon');


    //Return JS string with function to reset to subtheme's default colors
    //Make sure no whitespace exists! Otherwise Moodle functions strip out the html tags
    $js_str = <<<RESET_COLORS
<script type="text/javascript">
         $colors_var
        function resetDefaultColors(){
            var subtheme = document.getElementById('id_s_theme_avalon_subtheme').value;

            for (var i in colors[subtheme]){
                document.getElementById('id_s_theme_avalon_color' + i).value=colors[subtheme][i];
            }
        }
</script><center>
        <input type="button" onclick="return resetDefaultColors(document.getElementById('adminsettings'));" value="$resetDefaultColorsText" />
      </center>
RESET_COLORS;

    return $js_str;
}


