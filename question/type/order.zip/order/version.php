<?php

$plugin->version  = 2011080900;
$plugin->requires = 2010112400;

?>
