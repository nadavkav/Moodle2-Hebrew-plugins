<?PHP // $Id: qtype_order.php,v 1.2 2010/06/24 09:30:10 aaboyd Exp $ 
      // qtype_order.php - created with Moodle 1.9 + (Build: 20080402) (2007101509)

$string['addingorder'] = 'Anordnungsfrage hinzufügen';
$string['addmoreqblanks'] = 'Weitere Werte hinzufügen';
$string['defaultresponse'] = 'Ich weiß nicht';
$string['editingorder'] = 'Anordnungsfrage bearbeiten';
$string['filloutthreeitems'] = 'Sie müssen mindestens drei Werte in der richtigen Reihenfolge eingeben. Leere Felder werden ignoriert.';
$string['horizontal'] = 'Werte nebeneinander anzeigen';
$string['itemno'] = 'Wert {$a}';
$string['order'] = 'Anordnungsfrage';
$string['ordersummary'] = 'Werte werden per Drag-and-Drop entweder senkrecht oder nebeneinander eingeordnet.'

?>
