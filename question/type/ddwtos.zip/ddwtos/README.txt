Drag-and-drop, words to sentences question type

This question type requires that gapselect question type
https://github.com/moodleou/moodle-qtype_gapselect/
to be installed in order to work.

This question type was originally the work of Mahmoud Kassaei at the Open
University (http://www.open.ac.uk/). It was updated to work with the Moodle 2.1
question engine by Tim Hunt. It was then refactored extenstively by Jamie Pratt
(http://jamiep.org/) as part of creating the gapselect question type.


This question type is compatible with Moodle 2.1+.

To install using git, type this command in the root of your Moodle install
    git clone git://github.com/moodleou/moodle-qtype_ddwtos.git question/type/ddwtos
Then add question/type/ddwtos to your git ignore.

Alternatively, download the zip from
    https://github.com/moodleou/moodle-qtype_ddwtos/zipball/master
unzip it into the question/type folder, and then rename the new folder to ddwtos.
