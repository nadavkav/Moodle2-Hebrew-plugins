﻿<?php
/**
 * The language strings for the match question type.
 *    
 * @copyright &copy; 2007 Adriane Boyd
 * @author adrianeboyd@gmail.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package aab_order
 */

$string['addingddmatch'] = 'Добавление вопроса на соответствие (с перетаскиванием)';
$string['editingddmatch'] = 'Редактирование вопроса на соответствие (с перетаскиванием)';
$string['ddmatch'] = 'На соответствие (с перетаскиванием)';
$string['draganswerhere'] = 'Перетащите сюда ответ';

?>
