<?php
/**
 * The language strings for the match question type.
 *    
 * @copyright &copy; 2007 Adriane Boyd
 * @author adrianeboyd@gmail.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package aab_order
 */

$string['addingddmatch'] = 'ドラッグ＆ドロップ組み合わせ問題';
$string['editingddmatch'] = 'ドラッグ＆ドロップ組み合わせ問題の編集';
$string['ddmatch'] = 'ドラッグ＆ドロップ組み合わせ問題';
$string['draganswerhere'] = 'ここに答えをドラッグしてください';

?>
