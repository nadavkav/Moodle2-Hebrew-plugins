<?PHP // $Id: qtype_ddmatch.php,v 1.1 2010/06/21 16:12:24 aaboyd Exp $ 
      // qtype_ddmatch.php - created with Moodle 1.9 + (Build: 20080402) (2007101509)


$string['addingddmatch'] = 'Eine Drag-and-Drop Zuordnungsfrage hinzufügen';
$string['ddmatch'] = 'Drag-and-Drop-Zuordnung';
$string['draganswerhere'] = 'Ziehen Sie mit der Maus die Antwort an die richtige Stelle in diesem Bereich';
$string['editingddmatch'] = 'Drag-and-Drop Zuordnungsfrage bearbeiten';
$string['ddmatchsummary'] = 'Eine Erweiterung der Zuordnungsfrage, die dem Benutzer ermöglicht, Antworte per Drag-and-Drop zuzuordnen.';

?>
