<?php
/**
 * The language strings for the match question type.
 *
 * @copyright &copy; 2007 Adriane Boyd
 * @author adrianeboyd@gmail.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package aab_order
  * الترجمة العربية : الطرماح 1430/4/5
 */

$string['addingddmatch'] = 'إضافة سؤال مطابقة ( سحب و إسقاط )';
$string['editingddmatch'] = 'تحرير سؤال مطابقة ( سحب و إسقاط )';
$string['ddmatch'] = 'مطابقة ( سحب و إسقاط )';
$string['draganswerhere'] = 'أسقط الجواب هنا';

?>
