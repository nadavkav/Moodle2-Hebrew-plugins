<?php

$plugin->version  = 2011080500;
$plugin->requires = 2010112400;

?>
